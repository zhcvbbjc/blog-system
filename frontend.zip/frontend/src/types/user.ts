export interface UserProfile {
  id: number;
  username: string;
  email: string;
  avatarUrl?: string;
  bio?: string;
  role: 'ADMIN' | 'AUTHOR' | 'USER';
  joinedAt: string;
}

export interface AuthResponse {
  token: string;
  user?: UserProfile;
}

export interface RegisterResponse extends UserProfile {}

