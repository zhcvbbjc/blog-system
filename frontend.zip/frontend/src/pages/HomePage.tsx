import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { articleService } from '../services/api';
import ArticleCard from '../components/articles/ArticleCard';
import Loading from '../components/common/Loading';
import ErrorState from '../components/common/ErrorState';
import styles from './home.module.css';

function HomePage() {
  const { data, isLoading, error, refetch } = useQuery({
    queryKey: ['articles', { page: 0, size: 6 }],
    queryFn: () => articleService.list({ page: 0, size: 6 })
  });

  return (
    <div className={styles.container}>
      <section className={styles.hero}>
        <div>
          <p className={styles.badge}>AI 驱动 · 高效写作</p>
          <h1>智能博客系统</h1>
          <p>使用 React 前端与 Spring Boot 后端，享受现代化的创作体验。</p>
          <div className={styles.actions}>
            <Link to="/articles" className={styles.primaryBtn}>
              浏览最新文章
            </Link>
            <Link to="/register" className={styles.secondaryBtn}>
              立即创作
            </Link>
          </div>
        </div>
        <div className={styles.heroCard}>
          <h3>实时数据</h3>
          <p>文章：{data?.totalElements ?? '--'}</p>
          <p>互动：高质量点赞与评论</p>
          <p>AI 工具：摘要、标签、SEO</p>
        </div>
      </section>

      <section className={styles.listSection}>
        <div className={styles.sectionHeader}>
          <h2>最新文章</h2>
          <Link to="/articles">查看全部 →</Link>
        </div>
        {isLoading && <Loading />}
        {error && <ErrorState message={error.message} retry={refetch} />}
        <div className={styles.list}>
          {data?.content.map((article) => (
            <ArticleCard article={article} key={article.id} />
          ))}
        </div>
      </section>
    </div>
  );
}

export default HomePage;

